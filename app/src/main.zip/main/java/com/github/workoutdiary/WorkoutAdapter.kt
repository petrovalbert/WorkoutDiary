package com.github.workoutdiary

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WorkoutAdapter(
    private val onWorkoutClick: (Workout) -> Unit,
    private val onExerciseClick: (WorkoutEntry) -> Unit
) : ListAdapter<Workout, RecyclerView.ViewHolder>(WorkoutDiffCallback()) {

    companion object {
        private const val TYPE_WORKOUT = 0
        private const val TYPE_EXERCISE = 1
    }

    private val expandedWorkouts = mutableSetOf<Long>()

    override fun getItemViewType(position: Int): Int {
        val item = getItem(position)
        return if (item is Workout) TYPE_WORKOUT else TYPE_EXERCISE
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            TYPE_WORKOUT -> WorkoutViewHolder(
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_workout, parent, false)
            )
            TYPE_EXERCISE -> ExerciseViewHolder(
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_exercise, parent, false)
            )
            else -> throw IllegalArgumentException("Unknown view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is WorkoutViewHolder -> holder.bind(getItem(position) as Workout)
            is ExerciseViewHolder -> holder.bind(getItem(position) as WorkoutEntry)
        }
    }

    override fun submitList(list: List<Workout>?) {
        val items = mutableListOf<Any>()
        list?.forEach { workout ->
            items.add(workout)
            if (workout.isExpanded) {
                items.addAll(workout.exercises)
            }
        }
        super.submitList(items)
    }

    fun toggleWorkoutExpanded(date: Long) {
        val currentList = currentList.filterIsInstance<Workout>()
        val updatedList = currentList.map { workout ->
            if (workout.date == date) {
                workout.copy(isExpanded = !workout.isExpanded)
            } else {
                workout
            }
        }
        submitList(updatedList)
    }

    inner class WorkoutViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val title: TextView = itemView.findViewById(R.id.workout_title)
        private val date: TextView = itemView.findViewById(R.id.workout_date)
        private val expandIcon: ImageView = itemView.findViewById(R.id.expand_icon)

        fun bind(workout: Workout) {
            val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
            val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

            title.text = "Тренировка (${workout.exercises.size} упражнений)"
            date.text = "${dateFormat.format(Date(workout.date))} в ${timeFormat.format(Date(workout.date))}"

            expandIcon.setImageResource(
                if (workout.isExpanded) R.drawable.ic_expand_less
                else R.drawable.ic_expand_more
            )

            itemView.setOnClickListener {
                onWorkoutClick(workout)
            }
        }
    }

    inner class ExerciseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val name: TextView = itemView.findViewById(R.id.exercise_name)
        private val details: TextView = itemView.findViewById(R.id.exercise_details)

        fun bind(exercise: WorkoutEntry) {
            name.text = exercise.exerciseName
            details.text = "${exercise.targetMuscle} • ${exercise.weight}кг × ${exercise.reps}повт."

            itemView.setOnClickListener {
                onExerciseClick(exercise)
            }
        }
    }
}

class WorkoutDiffCallback : DiffUtil.ItemCallback<Any>() {
    override fun areItemsTheSame(oldItem: Any, newItem: Any): Boolean {
        return when {
            oldItem is Workout && newItem is Workout -> oldItem.date == newItem.date
            oldItem is WorkoutEntry && newItem is WorkoutEntry -> oldItem.id == newItem.id
            else -> false
        }
    }

    override fun areContentsTheSame(oldItem: Any, newItem: Any): Boolean {
        return oldItem == newItem
    }
}