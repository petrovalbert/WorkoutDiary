package com.github.workoutdiary

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "workout_entries")
data class WorkoutEntry (
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val date: Long,
    val exerciseName: String,
    val targetMuscle: String,
    val setNumber: Int,
    val weight: Double,
    val reps: Int
)