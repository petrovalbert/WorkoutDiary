package com.github.workoutdiary

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class WorkoutViewModel(private val datebase: AppDatabase) : ViewModel() {
    fun addTestEntry() {
        viewModelScope.launch {
            val testEntry = WorkoutEntry(
                date = System.currentTimeMillis(),
                exerciseName = "Squats",
                targetMuscle = "Quadriceps",
                setNumber = 1,
                weight = 70.0,
                reps = 10
            )

            datebase.workoutDao().insert(testEntry)
        }
    }
}