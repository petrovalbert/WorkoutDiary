package com.github.workoutdiary

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.workoutdiary.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: WorkoutAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupFab()
        observeWorkouts()

        // Добавляем тестовые данные при первом запуске
        viewModel.addSampleWorkouts()
    }

    private fun setupRecyclerView() {
        adapter = WorkoutAdapter(
            onWorkoutClick = { workout ->
                // Переключаем expanded состояние
                viewModel.toggleWorkoutExpanded(workout.date)
            },
            onExerciseClick = { exercise ->
                Snackbar.make(binding.root, "Упражнение: ${exercise.exerciseName}", Snackbar.LENGTH_SHORT).show()
            }
        )

        binding.workoutRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
    }

    private fun setupFab() {
        binding.fab.setOnClickListener {
            viewModel.addTestWorkout()
            Snackbar.make(it, "Тестовая тренировка добавлена!", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun observeWorkouts() {
        viewModel.workouts.observe(this) { workouts ->
            adapter.submitList(workouts)
        }
    }
}